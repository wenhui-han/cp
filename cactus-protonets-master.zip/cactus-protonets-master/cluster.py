import numpy as np
from tqdm import tqdm
from collections import defaultdict
import torch
import matplotlib.pyplot as plt
import os
from sklearn.cluster import KMeans


class Partition(object):
    def __init__(self, labels):
        partition = defaultdict(list)
        cleaned_partition = {}
        for ind, label in enumerate(labels):
            partition[label].append(ind)
        for label in list(partition.keys()):
            cleaned_partition[label] = np.array(partition[label], dtype=np.int)
        self.partition = cleaned_partition
        self.subset_ids = np.array(list(cleaned_partition.keys()))

    def __getitem__(self, key):
        return self.partition[key]


def get_partitions_kmeans(encodings, random_scaling, n_partitions, n_clusters):
    encodings_list = [encodings]
    if random_scaling:
        n_clusters_list = [n_clusters]
        for i in range(n_partitions - 1):
            weight_vector = np.random.uniform(low=0.0, high=1.0, size=encodings.shape[1])
            encodings_list.append(np.multiply(encodings, weight_vector))
    else:
        n_clusters_list = [n_clusters] * n_partitions
    assert len(encodings_list) * len(n_clusters_list) == n_partitions
    if n_partitions != 1:
        n_init = 3
        init = 'k-means++'
    else:
        n_init = 10
        init = 'k-means++'

    print('Length of encodings_list: {}, length of n_clusters_list: {}, number of inits: '.format(len(encodings_list),
                                                                                                  len(n_clusters_list)),
          n_init)

    kmeans_list = []

    for n_clusters in tqdm(n_clusters_list, desc='get_partitions_kmeans_n_clusters'):
        for encodings in tqdm(encodings_list, desc='get_partitions_kmeans_encodings'):
            kmeans = KMeans(n_clusters=n_clusters, init=init, n_init=n_init, max_iter=3000).fit(encodings)

            uniques, counts = np.unique(kmeans.labels_, return_counts=True)
            kmeans_list.append(kmeans)

            tqdm.write('Frequency: {}'.format(counts))

    partitions = []
    for kmeans in kmeans_list:
        partitions.append(Partition(labels=kmeans.labels_))
    return partitions


def load(opt, splits):
    encodings_dir = os.path.join(DATA_DIR, '{}_encodings'.format(opt['data.encoder']))
    filenames = os.listdir(encodings_dir)
    # print(filenames)

    for split in splits:
        split_filename = [filename for filename in filenames if opt['data.dataset'] in filename and split in filename]
        print(split_filename)
        assert len(split_filename) == 1
        split_filename = os.path.join(encodings_dir, split_filename[0])
        split_data = np.load(split_filename, allow_pickle=True)  # npz
        images = split_data['X']  # (index, H, W, C)
        labels = split_data['Y']
        encodings = split_data['Z']
        print('Num of images: ', len(labels))

        # mode = kmeans
        partitions = get_partitions_kmeans(encodings=encodings, random_scaling=False,
                                           n_partitions=opt['data.partitions'], n_clusters=opt['data.clusters'])
    return partitions, images


def select_clusters(partitions, images, num_clusters, max_size=20):
    i_partition = torch.randint(low=0, high=len(partitions), size=(1,), dtype=torch.int)
    partition = partitions[i_partition]

    sampled_subset_ids = np.random.choice(partition.subset_ids, size=num_clusters, replace=True)
    selected_images = {}
    for i, subset_id in enumerate(sampled_subset_ids):
        indices = np.random.choice(partition[subset_id], min(max_size, len(partition[subset_id])), replace=True)
        x = images[indices]
        x = x.astype(np.float32)
        x = torch.from_numpy(x)
        selected_images[i] = x
    return selected_images


def draw_and_save_img(selected_images, path='./cluster', img_size=64):
    output_path = os.path.join(path, logname)
    if not os.path.exists(output_path):
        os.mkdir(output_path)

    for key, cluster in selected_images.items():
        n = len(cluster)
        if n // 8 < 1:
            continue
        plt.figure(figsize=(8 * img_size, (n // 8) * img_size), dpi=1)
        for i, img in enumerate(cluster[:(n // 8) * 8]):
            plt.subplot(n // 8, 8, i + 1)

            plt.imshow(img)
            plt.axis('off')
        plt.savefig(os.path.join(output_path, '%s.png' % key), dpi=1)


def draw_and_save_sequence(selected_images, path='./cluster', img_size=64):
    output_path = os.path.join(path, logname)
    if not os.path.exists(output_path):
        os.mkdir(output_path)

    for key, cluster in selected_images.items():
        n = len(cluster)
        if n // 8 < 1:
            continue
        show_n_sketch(cluster, img_size, n, output_path, key)


def strokes_to_lines(strokes):
    """Convert stroke-3 format to polyline format."""
    x = 0
    y = 0
    lines = []
    line = []

    for i in range(len(strokes)):
        if strokes[i, 2] == 1:
            x += float(strokes[i, 0])
            y += float(strokes[i, 1])
            line.append([x, y])
            lines.append(line)
            line = []
        else:
            x += float(strokes[i, 0])
            y += float(strokes[i, 1])
            line.append([x, y])
    return lines


def show_n_sketch(data, img_size, n, output_path, key):
    """data is list of sketches."""

    plt.figure(figsize=(8 * img_size, (n // 8) * img_size), dpi=1)

    for i, strokes in enumerate(data[:(n // 8) * 8]):
        lines = strokes_to_lines(strokes)
        for idx in range(0, len(lines)):
            x = [x[0] for x in lines[idx]]
            y = [y[1] for y in lines[idx]]
            plt.subplot(n // 10, 10, i + 1)
            plt.plot(x, y, 'k-', linewidth=5)
        ax = plt.gca()
        plt.xticks([])
        plt.yticks([])
        ax.xaxis.set_ticks_position('top')
        ax.invert_yaxis()
    plt.savefig(os.path.join(output_path, '%s.png' % key), dpi=1)


DATA_DIR = './data'
# opt = {'data.dataset': 'oracle',
#        'data.encoder': 'acai',
#        'data.partitions': 1,
#        'data.clusters': 2500
#        }

opt = {'data.dataset': 'orcplot',
       'data.encoder': 'acai',
       'data.partitions': 1,
       'data.clusters': 6000
       }

splits = ['train', 'test']
# splits = ['train']

logname = '0219_%s_p%d_c%d' % (opt['data.dataset'], opt['data.partitions'], opt['data.clusters'])

partitions, images = load(opt, splits)

print('Get partitions.')

selected_images = select_clusters(partitions, images, num_clusters=50, max_size=40)

# draw_and_save_sequence(selected_images)
draw_and_save_img(selected_images)
print('Finished.')
