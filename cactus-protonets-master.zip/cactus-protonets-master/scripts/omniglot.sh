#!/usr/bin/env bash
device=6
dataset=qdoriaug
way=200
shot=1
query=20
encoder=acai
train_mode=kmeans  # 'ground_truth' oracle, which means supervised
clusters=500
partitions=1  # oracle 5
hdim=64
date=20210324
train_mode=kmeans

for encoder in acai
do
#    CUDA_VISIBLE_DEVICES=${device} python scripts/train/few_shot/run_train.py \
    CUDA_VISIBLE_DEVICES=${device} python run_train.py \
    --data.dataset ${dataset} \
    --data.way ${way} \
    --data.shot ${shot} \
    --data.query ${query} \
    --data.test_way 200 \
    --data.test_shot 40 \
    --data.test_query 20 \
    --data.train_episodes 5 \
    --data.test_episodes 5 \
    --data.cuda \
    --data.encoder ${encoder} \
    --data.train_mode ${train_mode} \
    --data.test_mode ground_truth \
    --data.clusters ${clusters} \
    --data.partitions ${partitions} \
    --model.x_dim 3,32,32 \
    --model.hid_dim ${hdim} \
    --train.epochs 600 \
    --log.exp_dir log \
    --log.date ${date}
done